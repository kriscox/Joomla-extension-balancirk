<?php

/**
 * @package     Joomla.Site
 * @subpackage  com_balancirk
 *
 * @copyright   Copyright (C) 2022 CoCoCo. All rights reserved.
 * @license     GNU General Public License version 3.
 */

defined('_JEXEC') or die;
?>

<div class="page-header">
	<h1>
		<?= $this->item->title; ?>
	</h1>
</div>


Hello <?php echo $this->member;
