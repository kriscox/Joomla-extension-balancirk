<?php

/**
 * @package 	com_balancirk
 * @subpackage 	student
 *
 * @copyright   Copyright (C) 2022 CoCoCo. All rights reserved.
 * @license     GNU General Public License version 3; see LICENSE.txt
 */

use Joomla\CMS\Language\Text;

defined('_JEXEC') or die('Restricted access');
?>
<h1>Students view</h1>

<h2>List of students</h2>