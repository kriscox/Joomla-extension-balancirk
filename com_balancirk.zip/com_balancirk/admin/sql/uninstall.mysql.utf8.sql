DROP TABLE IF EXISTS `#__Balancirk_Student`
