<?php

/**
 * @package 	joomla.Administrator
 * @subpackage 	com_Balancirk
 *
 * @copyright	Copyright (C) 2022 CoCoCo. All rights reserved.
 * @license	    GNU General Public License version 3; see LICENSE.txt
 */

namespace CoCoCo\Component\Balancirk\Administrator\View\Overview;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

/**
 * HtmlView class for main "Overview" Admin View
 * 
 * @since   __DEPLOY_VERSION__
 */
class HtmlView extends BaseHtmlView
{
    protected $items;
    /**
     * Display the main "Overview" view
     *
     * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
     * 
     * @return  void
     * 
     * @since   __DEPLOY_VERSION__
     */
    function display($tpl = null)
    {
        $this->items = $this->get('Items');
        parent::display($tpl);
    }
}
