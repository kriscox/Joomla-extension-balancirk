<?php

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;

$app = Factory::getApplication();
$doc = $app->getDocument();

/** Add the JavaScript to trigger Bootstrap modal for unsubscribe confirmation */
$doc->getWebAssetManager()->addInlineScript('
    jQuery(document).ready(function() {
        // Trigger unsubscribe modal on button click
        jQuery(".unsubscribe-btn").on("click", function(e) {
            e.preventDefault();
            var itemId = jQuery(this).val(); // Get the subscription ID
            jQuery("#unsubscribe-reason").val(""); // Clear any previous input
            jQuery("#unsubscribe-modal").data("item-id", itemId); // Store ID in modal data
            jQuery("#unsubscribe-modal").modal("show"); // Show the Bootstrap modal
        });

        // Handle confirm unsubscribe
        jQuery("#confirm-unsubscribe").on("click", function() {
            var itemId = jQuery("#unsubscribe-modal").data("item-id");
            var reason = jQuery("#unsubscribe-reason").val();

            // Create a hidden input to pass the reason in the form
            var form = jQuery("#adminForm");
            form.append("<input type=\'hidden\' name=\'unsubscribe_reason\' value=\'" + reason + "\'>");

            // Set the item ID in the form and submit
            jQuery("input[name=\'task\']").val("subscription.unsubscribe");
            form.append("<input type=\'hidden\' name=\'subscription_id\' value=\'" + itemId + "\'>");
            form.submit();
        });
    });
');
?>

<!-- Bootstrap Modal for Unsubscribe Confirmation -->
<div class="modal fade" id="unsubscribe-modal" tabindex="-1" aria-labelledby="unsubscribeModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="unsubscribeModalLabel"><?= Text::_('COM_BALANCIRK_UNSUBSCRIBE_CONFIRMATION_TITLE'); ?></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<p><?= Text::_('COM_BALANCIRK_UNSUBSCRIBE_CONFIRMATION_TEXT'); ?></p>
				<div class="mb-3">
					<label for="unsubscribe-reason" class="form-label"><?= Text::_('COM_BALANCIRK_UNSUBSCRIBE_REASON_OPTIONAL'); ?></label>
					<input type="text" class="form-control" id="unsubscribe-reason" placeholder="<?= Text::_('COM_BALANCIRK_UNSUBSCRIBE_REASON_PLACEHOLDER'); ?>">
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?= Text::_('COM_BALANCIRK_UNSUBSCRIBE_CANCEL_BUTTON'); ?></button>
				<button type="button" id="confirm-unsubscribe" class="btn btn-danger"><?= Text::_('COM_BALANCIRK_UNSUBSCRIBE_CONFIRM_BUTTON'); ?></button>
			</div>
		</div>
	</div>
</div>

<!-- Subscription Table -->
<div class="row">
	<div class="col-md-12">
		<form action="<?= Route::_('index.php?option=com_balancirk&task=subscription.unsubscribe'); ?>" method="post" id="adminForm" name="adminForm">
			<table class="table" id="subscriptionList">
				<thead>
					<tr>
						<th scope="col"><?= Text::_('COM_BALANCIRK_TABLE_TABLEHEAD_STUDENT'); ?></th>
						<th scope="col"><?= Text::_('COM_BALANCIRK_TABLE_TABLEHEAD_LESSON'); ?></th>
						<th scope="col"><?= Text::_('COM_BALANCIRK_TABLE_TABLEHEAD_YEAR'); ?></th>
						<th scope="col"><?= Text::_('COM_BALANCIRK_TABLE_TABLEHEAD_SUBSCRIBED'); ?></th>
						<th scope="col"><?= Text::_('COM_BALANCIRK_TABLE_TABLEHEAD_UNSUBSCRIBE'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($this->items as $i => $item) : ?>
						<tr class="row<?= $i % 2; ?>">
							<td><?= $this->escape($item->firstname); ?> <?= $this->escape($item->name); ?></td>
							<td><?= $this->escape($item->lesson); ?></td>
							<td><?= $this->escape($item->year); ?></td>
							<td>
								<?= ($item->subscribed == 0) ? '<span class="fas fa-check"></span>' : '<span class="fas fa-clock"></span>'; ?>
							</td>
							<td>
								<button type="button" class="btn btn-danger unsubscribe-btn" value="<?= $item->id; ?>">
									<span class="icon-purge"></span>
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<!-- Hidden Fields -->
			<input type="hidden" name="task" value="">
			<input type="hidden" name="boxchecked" value="0">
			<?= HTMLHelper::_('form.token'); ?>
		</form>
	</div>
</div>