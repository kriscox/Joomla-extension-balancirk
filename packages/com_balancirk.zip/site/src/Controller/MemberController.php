<?php

/**
 * @package	 Joomla.Site
 * @subpackage  com_balancirk
 *
 * @copyright   Copyright (C) 2022 CoCoCo. All rights reserved.
 * @license	 GNU General Public License version 3.
 */

namespace CoCoCo\Component\Balancirk\Site\Controller;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\FormController;
use CoCoCo\Component\Balancirk\Site\Model\MemberModel;
use Joomla\CMS\Component\ComponentHelper;

\defined('_JEXEC') or die;

/**
 * Balancirk member controller.
 *
 * @since   0.0.1
 */
class MemberController extends FormController
{
    /**
     * Cancel and return to homepage
     *
     * Implement the cancel button to return to the homepage on pressing the button with
     * task member.cancel
     *
     * @param   array	   $key	List of fields of the for
     *
     * @since   __BUMP_VERSION__
     **/
    public function cancel($key = null)
    {
        parent::cancel($key);

        // Set up the redirect back to the previous page (put in the header in HtmlView.php)
        $this->setRedirect("/");
    }

    /**
     * Register user
     *
     * Register the user based on the input values in $key
     *
     * @param   array	   $key	List of fields of the form
     *
     * @return	void
     *
     * @since   __BUMP_VERSION__
     **/
    public function register($key = null)
    {
        // Check if token is correct. Security measure
        $this->checkToken();

        // Get the curren application
        /** @var CMSApplication */
        $app = Factory::getApplication();

        // Get data from the form
        $data = $this->input->get('jform', array(), 'array');

        // Get the model and the form used
        /** @var memberModel */
        $model = $this->getModel('member');
        $form = $model->getForm($data, false);

        // Set the default redirection url
        $redirectUrl = Route::_('index.php?option=com_balancirk&view=member&layout=register', false);

        // Validate data and fill form data cache
        $validData = $model->validate($form, $data);
        $app->setUserState('com_balancirk.member.data', $data);

        if ($validData === false)
        {
            $errors = $model->getErrors();

            foreach ($errors as $error)
            {
                if ($error instanceof \Exception)
                {
                    $app->enqueueMessage($error->getMessage(), 'warning');
                }
                else
                {
                    $app->enqueueMessage($error, 'warning');
                }
            }
        }


        // Register the user
        if ($model->register($data))
        {
            // Rmove the form data in the session, using a unique identifier
            $app->setUserState('com_balancirk.member.data', null);

            // Get the redirect URL from the configuration
            $menuItemId = ComponentHelper::getParams('com_balancirk')->get('redirect_url', false);

            if ($menuItemId)
            {
                // If the redirect URL is set, use it
                $redirectUrl = Route::_('index.php?Itemid=' . (int) $menuItemId, false);
            }
            else
            {
                // Otherwise, redirect to the homepage
                $redirectUrl = Route::_('/', false);
            }
        }

        // Redirect back to the form in all cases
        $this->setRedirect($redirectUrl);
    }

    /**
     * Save member profile changes for the logged in user.
     *
     * @param   string  $key     The name of the primary key of the URL variable.
     * @param   string  $urlVar  The name of the URL variable if different from the primary key.
     *
     * @return  boolean
     *
     * @since   1.2.12
     */
    public function save($key = null, $urlVar = null)
    {
        $this->checkToken();

        $app = Factory::getApplication();
        $data = $this->input->post->get('jform', [], 'array');
        $memberId = (int) ($data['id'] ?? 0);
        $currentUserId = (int) $app->getIdentity()->id;

        if ($memberId <= 0 || $memberId !== $currentUserId) {
            $app->enqueueMessage(Text::_('JLIB_APPLICATION_ERROR_SAVE_NOT_PERMITTED'), 'warning');
            $this->setRedirect(Route::_('index.php?option=com_balancirk&view=member&layout=edit', false));

            return false;
        }

        /** @var MemberModel $model */
        $model = $this->getModel('member');
        $form = $model->getForm($data, false);
        $redirectUrl = Route::_('index.php?option=com_balancirk&view=member&layout=edit', false);
        $validData = $model->validate($form, $data);
        $app->setUserState('com_balancirk.member.data', $data);

        if ($validData === false) {
            foreach ($model->getErrors() as $error) {
                $app->enqueueMessage($error instanceof \Exception ? $error->getMessage() : $error, 'warning');
            }

            $this->setRedirect($redirectUrl);

            return false;
        }

        if ($model->edit($validData)) {
            $app->setUserState('com_balancirk.member.data', null);
            $app->enqueueMessage(Text::_('JSAVE'));
        } elseif ($model->getError()) {
            $app->enqueueMessage($model->getError(), 'warning');
        }

        $this->setRedirect($redirectUrl);

        return true;
    }
}
