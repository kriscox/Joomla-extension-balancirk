<?php
    namespace CoCoCo\Component\Balancirk\Administrator\Controller;
    defined('_JEXEC') or die;

    use Joomla\CMS\MVC\Controller\BaseController;

    /**
    * @package     Joomla.Administrator
    * @subpackage  com_balancirk
    *
    * @copyright   CoCoCo
    * @license     Copyright (C)  2022 GPL v2 All rights reserved.
    */

    /**
    * Default Controller of Balancirk component
    *
    * @package     Joomla.Administrator
    * @subpackage  com_balancirk
    */
    class DisplayController extends BaseController {
        /**
        * The default view for the display method.
        *
        * @var string
        */
        protected $default_view = 'main';

        public function display($cachable = false, $urlparams = array()) {
            return parent::display($cachable, $urlparams);

            /* TODO: Configure admin displaycontroller to use this message model.
            $document = Factory::getDocument();
            $viewName = $this->input->getCmd('view', 'login');
            $viewFormat = $document->getType();

            $view = $this->getView($viewName, $viewFormat);
            $view->setModel($this->getModel('Message'), true);

            $view->document = $document;
            $view->display();
            */
        }

    }
    