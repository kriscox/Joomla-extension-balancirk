DROP TABLE IF EXISTS `#__plg_webservices_balancirk_storage_table_1`;

    